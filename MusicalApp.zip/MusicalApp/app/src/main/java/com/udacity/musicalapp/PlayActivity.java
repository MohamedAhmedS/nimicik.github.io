package com.udacity.musicalapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.udacity.musicalapp.Model.SongModel;
import com.udacity.musicalapp.Utility.MusicUtil;

import java.util.ArrayList;

public class PlayActivity extends AppCompatActivity
{
    private TextView tvSongName, tvSongArtist, tvCurrentTime, tvTotalTime;
    private ImageView ivSongAlbumImg;
    private SeekBar seekBar;
    private ImageButton btnPrevious, btnPlay, btnNext, btnRepeat, btnShuffle;
    private MediaPlayer mediaPlayer = new MediaPlayer();

    private SongModel item;
    private SongModel.SongModelArray list;
    private int currentSong;
    private Handler seekBarUpdater = new Handler();
    private Runnable seekBarUpdate = new Runnable()
    {

        @Override
        public void run()
        {
            startUpdate();
        }
    };
    public Repeat repeat = Repeat.REPEAT_OFF;
    private boolean shuffle;

    private void init()
    {
        tvSongName = (TextView) findViewById(R.id.tvSongName);
        tvSongArtist = (TextView) findViewById(R.id.tvArtistName);
        tvCurrentTime = (TextView) findViewById(R.id.tvCurrentTime);
        tvTotalTime = (TextView) findViewById(R.id.tvTotalTime);
        ivSongAlbumImg = (ImageView) findViewById(R.id.ivAlbumArtImg);
        seekBar = (SeekBar) findViewById(R.id.songSeekbar);
        btnPrevious = (ImageButton) findViewById(R.id.btnPrevious);
        btnPlay = (ImageButton) findViewById(R.id.btnPlay);
        btnNext = (ImageButton) findViewById(R.id.btnNext);
        btnRepeat = (ImageButton) findViewById(R.id.btnSongRepeat);
        btnShuffle = (ImageButton) findViewById(R.id.btnSongShuffle);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

        list = new SongModel.SongModelArray((ArrayList<Intent>) getIntent().getSerializableExtra("list"));

        init();

        playSong(getIntent().getIntExtra("pos", 0));
        shuffle();
        repeat();
        seekBar();
        play();

    }

    private void shuffle()
    {
        btnShuffle.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                toggleShuffle(!shuffle);
            }
        });
    }

    private void toggleShuffle(boolean shuffle)
    {
        if (mediaPlayer != null) {
            this.shuffle = shuffle;
            btnShuffle.setBackgroundResource(shuffle ? R.drawable.icon_shuffle_active : R.drawable.icon_shuffle_deactive);
            if (shuffle) {
                playNext(true);
            }
        }
    }

    private void repeat()
    {
        btnRepeat.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                repeat(Repeat.get(repeat.get() + 1));
            }
        });
    }

    private void repeat(Repeat repeat)
    {
        if (mediaPlayer != null && repeat != null) {
            this.repeat = repeat;
            btnRepeat.setBackgroundResource(repeat == Repeat.REPEAT_ALL ? R.drawable.icon_repeat : repeat == Repeat.REPEAT_ONE ? R.drawable.icon_repeat_one : R.drawable.icon_no_repeat);
        }
    }

    private void seekBar()
    {
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
        {

            private boolean isSeekedByUser;

            @Override
            public void onProgressChanged(SeekBar sb, int i, boolean b)
            {
                if (isSeekedByUser) {
                    mediaPlayer.seekTo(i);
                }
                sb.setSecondaryProgress((i + 10) < sb.getMax() ? i + 10 : i);
                tvCurrentTime.setText(SongModel.formatDuration(i));
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb)
            {
                isSeekedByUser = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb)
            {
                isSeekedByUser = false;
            }
        });
    }

    private void play()
    {
        btnPlay.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                togglePlay();
            }
        });
    }

    private void togglePlay()
    {
        if (mediaPlayer != null) {
            togglePlay(mediaPlayer.isPlaying());
        }
    }

    private void togglePlay(boolean stop)
    {
        if (mediaPlayer != null) {
            if (btnPlay != null) {
                btnPlay.setBackgroundResource(stop ? R.drawable.icon_pause : R.drawable.icon_play);
            }
            stopUpdate();
            if (stop) {
                mediaPlayer.pause();
            } else {
                mediaPlayer.start();
                startUpdate();
            }
        }
    }

    private void startUpdate()
    {
        if (seekBar != null && mediaPlayer != null) {
            seekBar.setProgress(mediaPlayer.getCurrentPosition());
        }
        seekBarUpdater.postDelayed(seekBarUpdate, 1000);
    }

    private void stopUpdate()
    {
        seekBarUpdater.removeCallbacks(seekBarUpdate);
    }

    public void onPlayNext(View v)
    {
        playNext(true);
    }

    public void onPlayPrevious(View v)
    {
        playPrevious(true);
    }

    @SuppressLint({"WrongConstant", "ShowToast"})
    private void playSong(int pos)
    {
        if (list.size() < pos) {
            Toast.makeText(this, "Song not Found!", 0).show();
            finish();
        } else {
            currentSong = pos;
            item = list.get(pos);
            if (mediaPlayer.isPlaying()) {
                togglePlay(true);
            }
            try {
                mediaPlayer = MediaPlayer.create(this, Uri.parse("file://" + item.getPath()));
            } catch (Throwable e) {
                //Error reading the File
                Toast.makeText(this, "File not valid!", 0).show();
                finish();
            }
//            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener()
//            {
//
//                @Override
//                public void onPrepared(MediaPlayer mp)
//                {
//                    togglePlay(false);
//                }
//            });
//
//            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener()
//            {
//
//                @Override
//                public void onCompletion(MediaPlayer mp)
//                {
//                    togglePlay(true);
//                    if (repeat == Repeat.REPEAT_ONE) {
//                        mp.reset();
//                        togglePlay(false);
//                    } else {
//                        playNext(false);
//                    }
//                }
//            });


            Bitmap album_art = item.getAlbumArtist(this);
            if (album_art != null) {
                ivSongAlbumImg.setImageBitmap(album_art);
            } else {
                ivSongAlbumImg.setImageResource(R.drawable.music);
            }
            tvSongName.setText(item.getTitle());
            tvSongArtist.setText(item.getArtist());
            tvTotalTime.setText(SongModel.formatDuration((int) item.getDuration()));
            seekBar.setMax((int) item.getDuration());
            seekBar.setProgress(0);
        }
    }

    private void playNext(boolean byuser)
    {
        int i = currentSong + 1;
        if (shuffle) {
            i = MusicUtil.getRandom(0, list.size() - 1);
        }
        if (repeat == Repeat.REPEAT_ONE) {
            playSong(currentSong);
        } else if (i < list.size()) {
            playSong(i);
        } else if (byuser || repeat == Repeat.REPEAT_ALL) {
            playSong(0);
        } else {
            finish();
        }
    }

    private void playPrevious(boolean byuser)
    {
        int i = currentSong - 1;
        if (shuffle) {
            i = MusicUtil.getRandom(0, list.size() - 1);
        }
        if (repeat == Repeat.REPEAT_ONE) {
            playSong(currentSong);
        } else if (i >= 0) {
            playSong(i);
        } else if (byuser || repeat == Repeat.REPEAT_ALL) {
            playSong(list.size() - 1);
        } else {
            finish();
        }
    }

    @Override
    protected void onPause()
    {
        togglePlay(true);
        super.onPause();
    }

    @Override
    protected void onResume()
    {
        togglePlay(false);
        super.onResume();
    }

    private enum Repeat
    {
        REPEAT_OFF,
        REPEAT_ALL,
        REPEAT_ONE;

        public static Repeat get(int i)
        {
            i = i % 3;
            if (i == 0) {
                return REPEAT_OFF;
            } else if (i == 1) {
                return REPEAT_ONE;
            } else {
                return REPEAT_ALL;
            }
        }

        public int get()
        {
            if (this == REPEAT_OFF) {
                return 0;
            } else if (this == REPEAT_ONE) {
                return 1;
            } else {
                return 2;
            }
        }
    }
}
