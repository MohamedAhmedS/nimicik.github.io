package com.udacity.musicalapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;

import com.udacity.musicalapp.Adapters.MyViewHolder;
import com.udacity.musicalapp.Adapters.SongAdapter;
import com.udacity.musicalapp.Model.SongModel;

import java.util.List;

import static android.provider.MediaStore.Audio.AlbumColumns.ALBUM_ID;

public class SongActivity extends AppCompatActivity implements MyViewHolder.OnSongListener
{

    private String path, songsTitle, songsArtist;
    private SongModel.SongModelArray songModels = new SongModel.SongModelArray();
    private Cursor cursor;
    private String title;
    private String artist;
    private String album;
    //    private EditText searchBar;
    private int albumArt;
//    private String searchWord = "";
//    private List<SongModel> songList;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song);
        final RecyclerView rv = (RecyclerView) findViewById(R.id.recycler);
//        searchBar = findViewById(R.id.search_bar);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(new SongAdapter(this, getData(), this));
//        searchBar.clearFocus();

    }

    @SuppressLint("InlinedApi")
    private SongModel.SongModelArray getData()
    {
        ContentResolver contentResolver = getContentResolver();
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.IS_MUSIC + "!=0";
        cursor = contentResolver.query(uri, null, selection, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            int songTitle = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
            int songArtist = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
            long songDuration = 0;
            songDuration = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
            int albumArt = cursor.getColumnIndex(ALBUM_ID);

            do {
                songsTitle = cursor.getString(songTitle);
                songsArtist = cursor.getString(songArtist);

                path = cursor.getString(cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA));

                SongModel songModel = new SongModel();
                songModel.setTitle(cursor.getString(songTitle));
                songModel.setArtist(cursor.getString(songArtist));
                songModel.setDuration(cursor.getLong((int) songDuration));
                songModel.setPath(path);
                songModel.setAlbumImage(cursor.getLong(albumArt));
                songModels.add(songModel);

                title = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE));
                artist = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST));
                album = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM));
            } while (cursor.moveToNext());
        }
        return songModels;
    }

//    private void searchPosts(){
//
//                    if(searchWord.trim().isEmpty()){
//                            songList.add(post);
//
//                    } else {
//                        if(post.getCarType().toLowerCase().contains(searchWord)){
//                                songList.add(post);
//                            }
//
//                    }
//                }
//
//                SongAdapter songAdapter = new SongAdapter(getApplicationContext(), songList);
//                recyc.setAdapter(postAdapter);
//                postAdapter.notifyDataSetChanged();
//                if(progressBar.isShown()){
//                    progressBar.setVisibility(View.GONE);
//                }
//            }
//
//
//        });
//
//    }


    @Override
    public void onSongClick(int position)
    {
        startActivity(new Intent(SongActivity.this, PlayActivity.class)
                .putExtra("pos", position).putExtra("list", songModels.create()));
    }
}
