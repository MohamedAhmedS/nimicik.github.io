package com.udacity.musicalapp.Adapters;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.udacity.musicalapp.R;

import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener
{
    TextView songName, duration, artist;
    CircleImageView albumArtist;

    OnSongListener onSongListener;

    public MyViewHolder(View itemView, OnSongListener onSongListener)
    {
        super(itemView);
        songName = (TextView) itemView.findViewById(R.id.songName);
        artist = (TextView) itemView.findViewById(R.id.artist);
        duration = (TextView) itemView.findViewById(R.id.duration);
        albumArtist = (CircleImageView) itemView.findViewById(R.id.albumArtist);
        this.onSongListener = onSongListener;
        itemView.setOnClickListener(this);
    }

    @Override
    public void onClick(View view)
    {
        onSongListener.onSongClick(getAdapterPosition());
    }

    public interface OnSongListener
    {
        void onSongClick(int position);
    }
}
