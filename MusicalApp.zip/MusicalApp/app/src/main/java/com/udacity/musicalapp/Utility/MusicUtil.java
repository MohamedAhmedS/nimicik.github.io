package com.udacity.musicalapp.Utility;

import android.content.ContentUris;
import android.content.Context;
import android.net.Uri;
import android.provider.MediaStore;

import com.udacity.musicalapp.Model.SongModel;

import java.util.List;
import java.util.Locale;
import java.util.Random;

public class MusicUtil
{
    private static final String musicUtil = "MusicUtil";

    public static int getRandom(int from, int to)
    {
        Random random = new Random();
        return random.nextInt((to - from) + 1) + from;
    }

    public static String convertingDuration(long duration)
    {
        long minutes = (duration / 1000) / 60;
        long seconds = (duration / 1000) % 60;
        if (minutes < 60) {
            return String.format(Locale.getDefault(), "%01d:%02d", minutes, seconds);
        } else {
            long hours = minutes / 60;
            minutes = minutes % 60;
            return String.format(Locale.getDefault(),
                    "%d:%02d:%02d", hours, minutes, seconds);
        }
    }

    public static Uri getMediaStoreAlbumCoverUri(long albumId)
    {
        final Uri artWorkUri = Uri.parse("content://media/external/audio/albumart");

        Uri uri = ContentUris.withAppendedId(artWorkUri, albumId);
        return uri;
    }

    public static Uri getSongFileUri(int songId)
    {
        return ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, songId);
    }

    public static long getTotalDuration(Context context, List<SongModel> songModels)
    {
        long duration = 0;
        for (int i = 0; i < songModels.size(); i++) {
            duration += songModels.get(i).getDuration();
        }
        return duration;
    }


}
