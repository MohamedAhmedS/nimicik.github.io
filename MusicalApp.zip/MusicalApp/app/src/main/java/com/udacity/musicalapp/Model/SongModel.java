package com.udacity.musicalapp.Model;

import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class SongModel
{
    private String title;
    private String path;
    private String albumName;
    private String artistName;
    private String artist;
    private int trackNumber;
    private int artistId;
    private int year;
    private long durationLong;
    private long albumImage;

    public SongModel()
    {
        this(null);
    }

    public SongModel(Intent intent)
    {
        if (intent != null) {
            path = intent.getStringExtra("path");
            title = intent.getStringExtra("title");
            artist = intent.getStringExtra("artist");
            albumImage = intent.getLongExtra("albumImage", -1);
            durationLong = intent.getLongExtra("durationLong", -1);
        }
    }

    public static String formatDuration(int duration)
    {
        return String.format(Locale.getDefault(), "%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(duration),
                TimeUnit.MILLISECONDS.toSeconds(duration) - TimeUnit.MINUTES.toSeconds
                        (TimeUnit.MILLISECONDS.toMinutes
                                (duration)));
    }

    public void setPath(String path)
    {
        this.path = path;
    }

    public String getPath()
    {
        return this.path;
    }

    public long getAlbumImage()
    {
        return albumImage;
    }

    public void setAlbumImage(long albumImage)
    {
        this.albumImage = albumImage;
    }

    public long getDuration()
    {
        return durationLong;
    }

    public void setDuration(long duration)
    {
        this.durationLong = duration;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getArtist()
    {
        return artist;
    }

    public void setArtist(String artist)
    {
        this.artist = artist;
    }

    public Intent setValue(Intent intent)
    {
        if (intent != null) {
            intent.putExtra("path", path);
            intent.putExtra("title", title);
            intent.putExtra("artist", artist);
            intent.putExtra("albumImage", albumImage);
            intent.putExtra("durationLong", durationLong);
        }
        return intent;
    }

    public Bitmap getAlbumArtist(Context context)
    {
        Bitmap bitmap = null;
        try {
            ParcelFileDescriptor openFileDescriptor =
                    context.getContentResolver().openFileDescriptor
                            (ContentUris.withAppendedId
                                    (Uri.parse("content://media/external/audio/albumart"),
                                            getAlbumImage()), "r");
            if (openFileDescriptor != null) {
                bitmap = BitmapFactory.decodeFileDescriptor(openFileDescriptor.getFileDescriptor());
            }

        } catch (Throwable th) {

        }
        return bitmap;
    }

    public static class SongModelArray
    {
        private ArrayList<Intent> arrayIntent;

        public SongModelArray()
        {
            this(null);
        }

        public SongModelArray(ArrayList<Intent> arrayIntent)
        {
            if (arrayIntent == null) {
                this.arrayIntent = new ArrayList<Intent>();
            } else {
                this.arrayIntent = arrayIntent;
            }
        }

        public SongModelArray add(SongModel arrayIntent)
        {
            this.arrayIntent.add(arrayIntent.setValue(new Intent()));
            return this;
        }


        public SongModel get(int position)
        {
            return new SongModel(arrayIntent.get(position));
        }

        public int size()
        {
            return arrayIntent.size();
        }

        public ArrayList<Intent> create()
        {
            return arrayIntent;
        }

    }
}
