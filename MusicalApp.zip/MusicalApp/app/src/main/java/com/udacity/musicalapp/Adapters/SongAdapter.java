package com.udacity.musicalapp.Adapters;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.udacity.musicalapp.Model.SongModel;
import com.udacity.musicalapp.R;
import com.udacity.musicalapp.Utility.MusicUtil;

public class SongAdapter extends RecyclerView.Adapter<MyViewHolder>
{

    private Context context;
    private SongModel.SongModelArray songModels;
    private MyViewHolder.OnSongListener onSongListener;
    private LayoutInflater layoutInflater;

    public SongAdapter(Context context, SongModel.SongModelArray songModels, MyViewHolder.OnSongListener onSongListener)
    {
        this.context = context;
        this.songModels = songModels;
        this.onSongListener = onSongListener;
        this.layoutInflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view = layoutInflater.inflate(R.layout.activity_song_adapter, parent, false);
        return new MyViewHolder(view, onSongListener);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position)
    {
        SongModel songModel = songModels.get(position);
        holder.songName.setText(songModel.getTitle());
        holder.artist.setText(songModel.getArtist());
        String duration = MusicUtil.convertingDuration(songModel.getDuration());
        holder.duration.setText(duration);
        Bitmap albubArt = songModel.getAlbumArtist(context);
        if (albubArt != null) {
            holder.albumArtist.setImageBitmap(albubArt);
        }
    }

    @Override
    public int getItemCount()
    {
        return songModels.size();
    }
}
